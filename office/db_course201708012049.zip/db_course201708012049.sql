-- MySQL dump 10.13  Distrib 5.7.9, for Win64 (x86_64)
--
-- Host: localhost    Database: db_course
-- ------------------------------------------------------
-- Server version	5.7.18-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `courses_ref`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE IF NOT EXISTS `courses_ref` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'Код курса',
  `title` varchar(50) NOT NULL DEFAULT '' COMMENT 'Название курса',
  `length` tinyint(4) NOT NULL DEFAULT '0' COMMENT 'Продолжительность курса, часов',
  `description` text NOT NULL COMMENT 'Описание курса',
  `cathegory` varchar(50) NOT NULL DEFAULT '' COMMENT 'Категория курса',
  `previous` int(10) unsigned DEFAULT '0' COMMENT 'Требования к курсу',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 COMMENT='Таблица курсов с первичным ключом';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `courses_ref`
--

INSERT INTO `courses_ref` (`id`, `title`, `length`, `description`, `cathegory`, `previous`) VALUES (1,'Web-мастеринг. Основы серверного программирования',32,'Данный курс посвящен технологиям Веб-мастеринга. В курсе рассматриваются основные, базовые понятия, которые необходимы веб-мастеру для успешного создания решений на базе веб-серверов. Слушатели приобретают навыки администрирования веб-серверов, использования баз данных на веб-серверах, узнают основные характеристики и возможности наиболее часто используемых веб-серверов.\r\n\r\nКурс также будет полезен тем, кто обладает знаниями в объёме программы, но хочет их систематизировать, а также повысить свою эффективность за счёт новых приёмов и методов работы.','Web',0),(2,'Основы PHP программирования',32,'Вы научитесь профессионально создавать Web-сайты и Web-приложения при помощи языка PHP. Вы получите полное представление о возможностях применения технологии PHP – от настройки для совместной работы с серверами Apache и MySQL до создания профессиональных Web-интерфейсов к базам данных в Интернет и написания форума.\r\nВ курсе рассмотрено больше количество примеров и готовых наработок, что позволит слушателям практически сразу после окончания приступить к реальной работе с PHP.\r\n\r\nКурс также будет полезен тем, кто обладает знаниями в объёме программы, но хочет их систематизировать, а также повысить свою эффективность за счёт новых приёмов и методов работы.','Web',1),(3,'Профессиональное программирование на PHP 5',32,'Вы изучите профессиональные приёмы программирования на PHP, \r\n   сможете использовать полученные навыки для построения сложных, \r\n   эффективных и безопасных Web-приложений.','Web',2),(4,'Сервер MySQL 5',32,'Сервер MySQL очень распространен и часто используется в Веб–технологиях. На этом сервере базируются большинство сайтов и решений в Интернете.\r\n    На курсе «Сервер MySQL 5» рассматриваются основные приемы и методы эффективной работы с\r\n    сервером MySQL 5. Данный курс предназначен для разработчиков, которые планируют использовать\r\n    сервер MySQL в своей практике. Особенно курс будет интересен Веб– разработчикам, использующимм\r\n    PHP и Perl.\r\n    Курс также будет полезен тем, кто обладает знаниями в объёме программы,\r\n    но хочет их систематизировать, а также повысить свою эффективность за счёт новых\r\n    приёмов и методов работы.','Web',1),(5,'Современные XML технологии',32,'Вы научитесь применять XML-технологии в процессе создания сайтов и других Интернет-решений.\r\n   В современном мире эти технологии активно используются при решении самых разнообразных задач,\r\n   и, изучив их, Вы будете идти в ногу со временем.\r\n   Курс также будет полезен тем, кто обладает знаниями в объёме программы,\r\n   но хочет их систематизировать, а также повысить свою эффективность за счёт новых приёмов и методов работы','Web',2),(6,'Web-маркетинг',20,'Сегодня специалист по Интернет-технологиям должен не только владеть техническими навыками, но\r\n   и понимать значение своей работы для бизнеса заказчика. Никому не нужен сайт\r\n   (каким бы хорошим он ни был!), который не посещается целевой аудиторией. Успешно пройдя обучение\r\n   на этом уникальном авторском курсе, Вы научитесь привлекать максимальное количество\r\n   заинтересованных пользователей, проводить эффективную электронную рекламу, привлекать\r\n   внимание к представленной на сайте информации.\r\nКурс также будет полезен тем, кто обладает знаниями в объёме программы, но хочет их\r\nсистематизировать, а также повысить свою эффективность за счёт новых приёмов и методов работы.','Web',0),(7,'2310 Разработка Web-приложений ASP .NET',40,'Этот курс обеспечивает студентов знаниями и навыками, которые необходимы для разработки\r\n   Web приложений на базе Microsoft Visual Studio .NET и Microsoft ASP .NET.\r\nКурс также будет полезен тем, кто обладает знаниями в объёме программы,\r\nно хочет их систематизировать, а также повысить свою эффективность за счёт новых приёмов\r\nи методов работы.','Web',1);

--
-- Table structure for table `lessons`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE IF NOT EXISTS `lessons` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'Код урока',
  `teacher` int(10) unsigned DEFAULT NULL,
  `course` int(10) unsigned DEFAULT NULL,
  `room` char(5) NOT NULL DEFAULT '0' COMMENT 'Номер кабинета',
  `length` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT 'Продолжительность урока, часов',
  `lesson_date` date DEFAULT NULL COMMENT 'Дата урока',
  PRIMARY KEY (`id`),
  KEY `ixTeacher` (`teacher`),
  KEY `ixCourse` (`course`),
  CONSTRAINT `fkCourse` FOREIGN KEY (`course`) REFERENCES `courses_ref` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fkTeacher` FOREIGN KEY (`teacher`) REFERENCES `teachers_ref` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8 COMMENT='Таблица уроков с первичным ключом';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lessons`
--

INSERT INTO `lessons` (`id`, `teacher`, `course`, `room`, `length`, `lesson_date`) VALUES (1,1,1,'БК-1',4,'2006-09-15'),(2,2,2,'БК-2',4,'2006-09-15'),(3,3,3,'БК-3',4,'2006-09-17'),(4,4,4,'БК-4',4,'2006-09-18'),(5,5,5,'БК-5',4,'2006-09-19'),(6,1,6,'БК-6',4,'2006-09-20'),(7,2,7,'БК-7',4,'2006-09-21'),(8,3,1,'БК-8',4,'2006-09-22'),(9,4,2,'БК-9',4,'2006-09-23'),(10,5,3,'БК-10',4,'2006-09-23'),(11,1,4,'БК-11',4,'2006-09-25'),(12,2,5,'БК-12',4,'2006-09-26'),(13,3,6,'БК-13',4,'2006-09-27'),(14,4,7,'БК-14',4,'2006-09-28'),(15,5,1,'БК-15',4,'2006-09-29'),(16,1,2,'БК-16',4,'2006-09-30'),(17,2,3,'БК-17',4,'2006-10-01'),(18,3,4,'БК-18',4,'2006-10-02'),(19,4,5,'БК-19',4,'2006-10-02');

--
-- Table structure for table `teachers_ref`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE IF NOT EXISTS `teachers_ref` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'Код учителя',
  `name` varchar(50) NOT NULL DEFAULT '' COMMENT 'Имя учителя',
  `addr` varchar(200) NOT NULL DEFAULT '' COMMENT 'Адрес учителя',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COMMENT='Таблица учителя с первичным ключом';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `teachers_ref`
--

INSERT INTO `teachers_ref` (`id`, `name`, `addr`) VALUES (1,'Иванов Иван Иванович','Москва, Бакунинская, 71'),(2,'Петров Петр Петрович','Москва, Госпитальный пер. 4/5'),(3,'Сидоров Сидор Сидорович','Москва, Цветной бульвар, 19'),(4,'Пупкин Василий Иванович','Щелково, Комарова, 21'),(5,'Сумкин Федор Михайлович','Королев, проспект Космонавтов, 15');
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-08-01 20:49:22
