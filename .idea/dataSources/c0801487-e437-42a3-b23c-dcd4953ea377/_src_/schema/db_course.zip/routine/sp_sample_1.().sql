CREATE PROCEDURE sp_sample_1()
  BEGIN 
    SELECT 'Список преподавателей' AS ' ';
    SELECT name from teachers_ref ORDER BY name;
  END;
