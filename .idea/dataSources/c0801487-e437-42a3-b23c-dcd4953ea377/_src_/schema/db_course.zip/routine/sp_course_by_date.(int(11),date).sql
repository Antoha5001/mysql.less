CREATE PROCEDURE sp_course_by_date(IN idteacher INT, IN date_course DATE)
  BEGIN
    SELECT courses_ref.id, courses_ref.title
    FROM courses_ref
      INNER JOIN lessons ON lessons.course = courses_ref.id
    WHERE lessons.lesson_date = date_course
          AND lessons.teacher = idteacher;
  END;
