CREATE VIEW cityrus AS
  SELECT
    `world`.`city`.`ID`          AS `ID`,
    `world`.`city`.`Name`        AS `Name`,
    `world`.`city`.`CountryCode` AS `CountryCode`,
    `world`.`city`.`District`    AS `District`,
    `world`.`city`.`Population`  AS `Population`
  FROM `world`.`city`
  WHERE (`world`.`city`.`CountryCode` = 'RUS');
