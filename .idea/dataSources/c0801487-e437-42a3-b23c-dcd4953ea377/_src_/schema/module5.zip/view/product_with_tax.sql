CREATE VIEW product_with_tax AS
  SELECT
    `module5`.`product`.`id`             AS `id`,
    `module5`.`product`.`title`          AS `title`,
    `module5`.`product`.`price`          AS `price`,
    `module5`.`product`.`quo`            AS `quo`,
    (`module5`.`product`.`price` * 1.18) AS `price_tax`
  FROM `module5`.`product`
  WHERE (`module5`.`product`.`quo` > 0);
